var express = require('express'); 
var app = express();

var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false }); 
var jsonParser = bodyParser.json();

var path = require('path');

var cors = require("cors")
var cor = cors();
app.use(cor);
app.use(express.static(path.join(__dirname, "../public")));

var furniture = require('../model/furniture.js');

app.get('/api/category/:catid/furniture', function (req, res) {
    var catid = req.params.catid;
    furniture.getFurnitureByCat(catid, function (err, result) {
        if (!err) {
            res.send(result);
        } else {
            console.log(err);
            res.status(500).send(err);
        }
    });
});

var user = require('../model/user');

app.get('/api/user', function (req, res) {
    user.getUser(function (err, result) {
        if (!err) {
            res.send(result);
        } else {
            console.log(err);
            res.status(500).send(err);
        }
    })
});

app.post('/api/user', urlencodedParser, jsonParser, function (req, res) {
    var useremail = req.body.useremail;
    var userpassword = req.body.userpassword;
    var name = req.body.name;

    user.addUser(useremail, userpassword, name, function (err, result) {
        if (!err) {
            console.log(result);
            res.send(result.affectedRows + ' record ditambahkan');
        } else {
            console.log(err);
            res.status(500).send(err.code);
        }
    })
});

app.delete('/api/user/:userid', function (req, res) {
    var userid = req.params.userid

    user.deleteUser(userid, function (err, result) {
        if (!err) {
            console.log(result);
            res.send(result.affectedRows + ' record dihapus');
        } else {
            console.log(err);
            res.status(500).send(err.code);
        }
    })
});

app.post('/api/user/:userid', urlencodedParser, jsonParser, function (req, res) {
    var userpassword = req.body.userpassword;
    var name = req.body.name;
    var userid = req.params.userid;

    user.updateUser(userpassword, name, userid, function (err, result) {
        if (!err) {
            console.log(result);
            res.send(result.affectedRows + ' record diubah');
        } else {
            console.log(err);
            res.status(500).send(err.code);
        }
    })
});

// var mobil = require('../model/mobil'); 
// app.get('/api/mobil', function (req, res) {     
//     mobil.ambilsemuamobil(function(err, result){         
//         if (!err) { 
//     res.send(result); 
// }         else { 
//     console.log(err); 
//     res.status(500).send(err); 
// } 
// }) 
// }) 

var barang = require('../model/barang');

app.get('/api/barang', function (req, res) {
    barang.getBarang(function (err, result) {
        if (!err) {
            res.send(result);
        } else {
            console.log(err);
            res.status(500).send(err);
        }
    })
});

app.get('/api/barang/:catid', function (req, res) {
    var catid = req.params.catid;
    barang.getBarangById(catid, function (err, result) {
        if (!err) {
            res.send(result);
        } else {
            console.log(err);
            res.status(500).send(err);
        }
    });
});

module.exports = app