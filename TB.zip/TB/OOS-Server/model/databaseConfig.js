var mysql = require ('mysql');
var dbconnect = mysql. createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "tb_oos"
   });
   module.exports = dbconnect    