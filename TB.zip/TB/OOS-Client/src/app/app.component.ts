import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  public appPages = [
    {
      title: 'Beranda',
      url: '/home',
      icon: 'home'
    },
    {
      title: 'Linimasa',
      url: '/list',
      icon: 'list'
    },
    {
      title: 'Pengajuan',
      url: '/tambah-pinjaman',
      icon: 'arrow-dropright-circle'
    },
    {
      title: 'Pengembalian',
      url: '/list',
      icon: 'arrow-dropleft-circle'
    }
  ];

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}
