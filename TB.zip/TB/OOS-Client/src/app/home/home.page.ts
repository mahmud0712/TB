import { Component } from '@angular/core'; 
import { Router } from '@angular/router'; 
import { HutangService } from '../hutang.service'; 
@Component({   
  selector: 'app-home',   
  templateUrl: 'home.page.html',   
  styleUrls: ['home.page.scss'], 
}) 
export class HomePage {   
  listDataPinjaman: any = [];   
  slideOpts = {
    effect: 'flip'
  };
  constructor(     
    public router: Router,     
    public hutang: HutangService 
  ) 
  {     setTimeout(() => { 
      this.listDataPinjaman = this.hutang.listDataPinjaman; 
    }, 1000); 
  }  
  goTambahPinjaman() { 
    this.router.navigate(['/tambah-pinjaman']); 
  } 
  hapusDataPinjaman(item) {     this.hutang.hapusData(item); 
  } 
  hapusSemuaDataPinjaman() {     this.hutang.hapusSemuaData();     this.listDataPinjaman = []; 
  } 

  
} 
 
