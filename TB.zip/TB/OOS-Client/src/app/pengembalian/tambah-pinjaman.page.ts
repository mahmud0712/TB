import { Component, OnInit } from '@angular/core'; 
import { HutangService } from '../hutang.service'; 
import { Router } from '@angular/router'; 
 
@Component({ 
  selector: 'app-tambah-pinjaman',   templateUrl: './tambah-pinjaman.page.html',   styleUrls: ['./tambah-pinjaman.page.scss'], 
}) 
export class TambahPinjamanPage implements OnInit {   jenis: any = null;   penerima: any = null;   jumlah: any = null;   deskripsi: any = null;   tanggalPeminjaman: any = null;   tanggalPengembalian: any = null; 
   constructor( 
    public hutang: HutangService,     public router: Router) { } 
   ngOnInit() {   }   simpanData() {     var tempData = {       jenis: this.jenis,       penerima: this.penerima,       jumlah: this.jumlah,       deskripsi: this.deskripsi, 
      tanggalPeminjaman: this.tanggalPeminjaman,       tanggalPengembalian: this.tanggalPengembalian 
    } 
    this.hutang.simpanData(tempData); 
    this.hutang.showMessage("Data berhasil disimpan");     this.router.navigate(['/home']); 
  } 
 
} 
